library(testthat)
library(tidygeoRSS)

test_check("tidygeoRSS")
