#' Argument Matching
#'
#' See [strex::match_arg()].
#'
#' @inheritParams strex::match_arg
#'
#' @export
match_arg <- strex::match_arg

#' @rdname match_arg
#' @export
str_match_arg <- match_arg
