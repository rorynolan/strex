#' Split a string by its numeric characters.
#'
#' See [strex::str_split_by_nums()].
#'
#' @inheritParams strex::str_split_by_nums
#'
#' @export
str_split_by_nums <- strex::str_split_by_nums
