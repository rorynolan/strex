#' Argument Matching
#'
#' See [strex::match_arg()].
#'
#' @inheritParams strex::match_arg
#'
#' @export
match_arg <- strex::match_arg
