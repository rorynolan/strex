#' Trim something other than whitespace
#'
#' See [strex::str_trim_anything()].
#'
#' @inheritParams strex::str_trim_anything
#'
#' @export
trim_anything <- strex::str_trim_anything
